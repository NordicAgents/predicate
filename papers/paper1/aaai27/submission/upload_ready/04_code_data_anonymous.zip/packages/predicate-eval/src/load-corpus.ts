import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import type { StorageAdapter } from 'predicate-mcp/src/storage/index.js';
import { getAdapter } from 'predicate-mcp/src/storage/index.js';
import { kgAssert } from 'predicate-mcp/src/tools/kg-assert.js';
import { withCodebaseTBox } from 'predicate-mcp/tests/fixtures/with-codebase.js';

const C = 'https://example.org/anonymous-predicate/codebase#';
const DOM = 'https://example.org/anonymous-predicate/codebase';
const ROOT = join(import.meta.dirname, '..', 'fixtures', 'demo-corpus');

function iriForFile(name: string): string { return `${DOM}/${name}`; }
function iriForFn(file: string, name: string): string { return `${DOM}/${file}#${name}`; }
function iriForEnv(name: string): string { return `${DOM}/env/${name}`; }

const importRE = /import\s+\{[^}]*\}\s+from\s+['"]\.\/([\w-]+)['"]/g;
const fnRE = /export\s+function\s+(\w+)\s*\(/g;
const envRE = /process\.env\.([A-Z0-9_]+)/g;

export async function main(client: StorageAdapter = getAdapter()): Promise<void> {
  // Seed the codebase schema so the asserts below have declared predicates.
  // Idempotent: a no-op when the TBox is already loaded (e.g. after `predicate
  // init` or in tests that seed it in beforeAll).
  await withCodebaseTBox(client);

  const files = readdirSync(ROOT).filter((f) => f.endsWith('.ts'));
  for (const f of files) {
    const path = join(ROOT, f);
    const src = readFileSync(path, 'utf8');
    const fileIri = iriForFile(f);

    await kgAssert(client, {
      subject: fileIri, predicate: `${C}path`,
      object: { type: 'literal', value: f },
      source: path, confidence: 1, method: 'fs-read',
    });
    await kgAssert(client, {
      subject: fileIri, predicate: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
      object: { type: 'uri', value: `${C}File` },
      source: path, confidence: 1, method: 'fs-read',
    });

    for (const m of src.matchAll(importRE)) {
      await kgAssert(client, {
        subject: fileIri, predicate: `${C}imports`,
        object: { type: 'uri', value: iriForFile(`${m[1]}.ts`) },
        source: path, confidence: 0.95, method: 'regex-import',
      });
    }

    const declared = new Set<string>();
    for (const m of src.matchAll(fnRE)) {
      const fnIri = iriForFn(f, m[1]!);
      declared.add(m[1]!);
      await kgAssert(client, {
        subject: fnIri, predicate: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
        object: { type: 'uri', value: `${C}Function` },
        source: path, confidence: 1, method: 'regex-fn',
      });
      await kgAssert(client, {
        subject: fnIri, predicate: `${C}declaredIn`,
        object: { type: 'uri', value: fileIri },
        source: path, confidence: 1, method: 'regex-fn',
      });
    }

    for (const m of src.matchAll(envRE)) {
      const envIri = iriForEnv(m[1]!);
      await kgAssert(client, {
        subject: envIri, predicate: 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',
        object: { type: 'uri', value: `${C}EnvVar` },
        source: path, confidence: 1, method: 'regex-env',
      });
      for (const fn of declared) {
        await kgAssert(client, {
          subject: iriForFn(f, fn), predicate: `${C}reads`,
          object: { type: 'uri', value: envIri },
          source: path, confidence: 0.6, method: 'regex-env-near-fn',
        });
      }
    }
  }
  console.log('corpus loaded');
}

// Only run as a standalone script — not when imported as a module (e.g. by tests).
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((e) => { console.error(e); process.exit(1); });
}
